# ProductivityBooster

A chrome extension designed to boost your productivity. All you have to do is add a todo list and a list of websites that hinder your productivity and the extension will do its best to keep you on track with your goals for the day.
